package com.trios;
import javax.persistence.*;

@Entity
@Table(name="track")
public class Track {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="TrackId", unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int TrackId;

    @Column(name="Name")
    private String Name;

    @Column(name="AlbumId")
    private int AlbumId;

    @Column(name="MediaTypeId")
    private int  MediaTypeId;

    @Column(name="GenreId")
    private int GenreId;

    @Column(name="Composer")
    private String Composer;

    @Column(name="Milliseconds")
    private double Milliseconds;

    @Column(name="Bytes")
    private double Bytes;

    @Column(name="UnitPrice")
    private float UnitPrice;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getTrackId() {
        return TrackIdId;
    }

    public void setTrackId(int TrackId) {
        this.TrackId = TrackId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int  getAlbumId() {
        return AlbumId;
    }

    public void setAlbumId(int AlbumId) {
        this.AlbumId = AlbumId;
    }

    public int getMediaTypeId() {
        return MediaTypeId;
    }

    public void setMediaTypeId(int MediaTypeId) {
        this.MediaTypeId = MediaTypeId;
    }

    public int getGenreId() {
        return GenreId;
    }

    public void setGenreId(int GenreId) {
        this.GenreId = GenreId;
    }

    public String getComposer() {
        return Composer;
    }

    public void setComposer(String Composer) {
        this.Composer = Composer;
    }

    public double getMilliseconds() {
        return Milliseconds;
    }

    public void setMilliseconds(double Milliseconds) {
        this.Milliseconds = Milliseconds;
    }

    public double getBytes() {
        return Bytes;
    }

    public void setBytes(double Bytes) {
        this.Bytes = Bytes;
    }

    public float getUnitPrice() {
        return UnitPrice;
    }

    public void setUnitPrice(float UnitPrice) {
        this.UnitPrice = UnitPrice;
    }
}
